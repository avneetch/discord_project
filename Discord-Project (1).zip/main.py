# bot.py
import os
import discord
from dotenv import load_dotenv
import json
import requests
from keepalive import keep_alive

#this bot greets new members to the server and provides members with inspirational quotes from an API 
#this bot is hosted with replit & uptime robot

load_dotenv()

TOKEN = os.environ['DISCORD_TOKEN']
GUILD = os.environ['DISCORD_GUILD']

#pulls API quote
def get_quote():
    URL = "https://api.quotable.io/random"
    try:
        response = requests.get(URL)
    except:
        print("Error while calling API...")
    res = json.loads(response.text)
    return res['content'] + "-" + res['author']
  
client = discord.Client()

# notifies me if connected
@client.event
async def on_ready():
  print(f'{client.user.name} has connected to Discord!')

# greets new members and explains the bot 
@client.event
async def on_member_join(member):
    await member.create_dm()
    await member.dm_channel.send(
        f'Hi {member.name}, welcome to my truly inspirational Discord server! Try saying "Hello"!'
    )

# responds to messages either with information on how to use bot or with a quote
@client.event
async def on_message(message):
    if message.author == client.user:
        return

    if message.content == "Hello": 
        response = get_quote()
        await message.channel.send(response)
    else: 
      response_2 = "Try saying 'Hello' to get some inspiration for the day!"
      await message.channel.send(response_2)

keep_alive()
client.run(TOKEN)
